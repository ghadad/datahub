<template>
<div> <h1>New Job</h1>
</div>
</template>
