import Vue from "vue";
import Axios from "axios";
export default Axios;