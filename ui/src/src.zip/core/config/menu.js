export default {
    leftMenu: [{
            title: "Projects",
            icon: "settings_applications",
            routerLink :"/project"
        },   {
            title:"Databases",icon:"storage",
            routerLink :"/database"
        },
        {
            title: "Jobs",
            icon: "move_to_inbox",
            routerLink :"/job"
        },
        {
            title: "API-s",
            icon: "move_to_inbox",
            routerLink :"/api"
        },  
        {
            title:"Docs",icon:"import_contacts",
            routerLink :"/projects"
        },
        {
            title:"Docs",icon:"import_contacts",
            routerLink :"/docs"
        }
    ]
};